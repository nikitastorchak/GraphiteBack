
export const categories = [
  {
    name: "Graphite Travel",
    icon: ""
  },
  {
    name: "Акции",
    icon: ""
  },
  {
    name: "Хочу премиум",
    icon: ""
  },
  {
    name: "Graphite для бизнеса",
    icon: ""
  },
  {
    name: "Зона лучших цен",
    icon: ""
  }

]
